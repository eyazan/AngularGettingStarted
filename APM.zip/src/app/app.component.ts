
// // Import
// // Component burada member name 
// import { Component } from '@angular/core';

// import { Component } from "@angular/core";

// // Metadata & Template 
// // Decarator ; (Component) A function that adds metadata to a class, its members, or its method arguments.
// //  
//  @Component({
//    // selector defines the component's directive name.
//    // template kısmında layout view edilen yer
//    // {{Binding yapılan kısım}}
//   selector: 'pm-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })

// // Class export olması diğer kişiler tarafından bu componentin kullanılmasını sağlıyor
// export class AppComponent {
//   // title Property name 
//   pageTitle = 'Acme Product Management';
// }


import { Component } from "@angular/core";

// Component decarator -  Prefix with @; Suffix with ()
@Component({
  // selector : Component name in HTML
selector: 'pm-root',
// template: View's HTML 
template: `<nav class='navbar navbar-expand navbar-light bg-light'>
            <a class='navbar-brand'>{{pageTitle}}</a>
            <ul class='nav nav-pills'>
              <li><a class='nav-link' routerLink='/welcome'> Home </a></li>
              <li><a class='nav-link' routerLink='/products'>Product </a></li>
            </ul>
</nav>
<div class='container'>
  <router-outlet></router-outlet>
</div>
          `
})

export class AppComponent {
  pageTitle: string = 'Acme Product Management';
}
