import { EmitterVisitorContext } from "@angular/compiler";
import { Component, Input, OnChanges, SimpleChanges,EventEmitter,Output } from "@angular/core";
// import {  } from "stream";

@Component({
  selector: 'pm-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css']
})

export class StarComponent implements OnChanges {

@Input() rating: number = 0;
cropWidth: number = 75;
@Output() ratingClicked: EventEmitter<string> = new EventEmitter<string>();

ngOnChanges(): void {
   this.cropWidth = this.rating * 75 / 5;
}

// yıldızlara tıklaıdğımız zaman console log da kaç yıldız olduğu yazıyor 'Handling events' 
onClick(): void {
    this.ratingClicked.emit('The rating ${this.rating} was clicked!');
}
}